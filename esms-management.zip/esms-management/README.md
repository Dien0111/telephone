# eSMS Control — Bộ quản trị SMS / Voice OTP

Web App tách Frontend và Backend để triển khai theo mô hình **Netlify (Frontend) + Render (Node.js Backend) + eSMS API**.

## 1. Những gì đã có

- Dashboard quản trị, trạng thái môi trường, số liệu và hoạt động gần đây.
- Đăng nhập Admin bằng JWT, giới hạn thử đăng nhập và giới hạn request gửi.
- Chế độ **Demo**: mô phỏng gửi SMS/Voice OTP, tác vụ lên lịch và nhật ký. Backend không gọi ra eSMS trong chế độ này.
- Chế độ **Live**: chỉ được phép khi bật đủ cờ trên Backend và có API Key/Secret Key hợp lệ.
- Gửi SMS OTP/CSKH qua endpoint POST JSON của eSMS; Brandname được lấy từ biến môi trường Backend.
- Luồng Voice OTP theo tài liệu eSMS với `SmsType=8`, chỉ nhận mã 4–8 chữ số; cần xác nhận quyền dịch vụ/template với eSMS trước khi bật.
- Lịch tác vụ chạy một lần, Backend kiểm tra mỗi 10 giây; cho phép hủy khi lịch chưa chạy.
- Nhật ký che một phần số điện thoại; không ghi API Key/Secret Key.
- Callback HTTPS GET có token riêng để cập nhật trạng thái cuối của SMS từ eSMS.
- PostgreSQL để lưu trữ bền vững; JSON local chỉ là phương án chạy thử.

> Lưu ý: eSMS trả `CodeResult=100` nghĩa là request được tiếp nhận, không chứng minh SMS/cuộc gọi đã đến người nhận. Muốn xác nhận kết quả cuối cần tích hợp callback hoặc API tra cứu trạng thái theo gói dịch vụ của tài khoản.

## 2. Chạy local

Yêu cầu: **Node.js 20 trở lên**. Trên Windows có thể chạy `start-demo.bat` để cài dependencies lần đầu, mở Backend và tự bật giao diện Demo; file này ép `APP_MODE=demo` và tắt Live/SMS/Voice trong tiến trình được khởi chạy.

### Backend

```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

Windows CMD có thể sao chép `.env.example` thành `.env` bằng lệnh:

```bat
copy .env.example .env
```

Mặc định `APP_MODE=demo`. Local Demo mặc định:

- Email: `admin@demo.local`
- Mật khẩu: `Demo@12345`

Backend chạy tại `http://localhost:4000`; kiểm tra `http://localhost:4000/health`.

### Frontend

Mở terminal thứ hai:

```bash
cd frontend
npm run build
```

Có thể mở `frontend/index.html` bằng Live Server (VS Code) hoặc chạy một static server tại thư mục `frontend`. File `frontend/config.js` mặc định trỏ tới `http://localhost:4000`.

Không mở Frontend từ bản `dist` trước khi chạy build; build tạo `dist/config.js`.

## 3. Triển khai Backend lên Render

Tạo một **Web Service** trên Render từ repository Git của dự án:

| Trường | Giá trị |
|---|---|
| Root Directory | `backend` |
| Runtime | Node |
| Build Command | `npm install` |
| Start Command | `npm start` |

Thêm Environment Variables trên Render:

```env
NODE_ENV=production
APP_MODE=demo
PORT=4000
ADMIN_EMAIL=admin@your-domain.vn
ADMIN_PASSWORD=THAY_BANG_MAT_KHAU_DAI_VA_RIENG
JWT_SECRET=THAY_BANG_CHUOI_NGAU_NHIEN_IT_NHAT_32_KY_TU
CORS_ORIGINS=https://TEN-SITE-CUA-BAN.netlify.app
LIVE_SEND_ENABLED=false
SMS_ENABLED=false
VOICE_ENABLED=false
ESMS_SANDBOX=1
PUBLIC_BACKEND_URL=https://TEN-BACKEND.onrender.com
ESMS_CALLBACK_TOKEN=CHUOI_NGAU_NHIEN_DAI_VA_RIENG
```

Render cấp `PORT` động; Backend đã đọc biến này. Không tự đặt API Key vào repository hoặc Frontend. Vì scheduler chạy bên trong tiến trình Node.js, hãy chọn loại Web Service có thể duy trì hoạt động liên tục; instance tự sleep có thể làm lịch chạy trễ cho đến khi Backend khởi động lại.

### PostgreSQL (khuyến nghị)

Tạo PostgreSQL database trên Render, sau đó đưa connection string nội bộ vào biến `DATABASE_URL` của Web Service. Backend tự tạo bảng `message_jobs` và `message_logs` khi khởi động.

Nếu không cấu hình `DATABASE_URL`, Backend lưu vào `backend/data/store.json`. Cách này phù hợp local/demo; filesystem của Web Service có thể không bền vững qua lần deploy hoặc thay thế instance, vì vậy không dùng JSON local làm kho lịch/nhật ký production.

Sau khi deploy, kiểm tra `https://TEN-BACKEND.onrender.com/health`.

## 4. Triển khai Frontend lên Netlify

Kết nối repository với Netlify. File `netlify.toml` đã cấu hình:

- Base directory: `frontend`
- Build command: `npm run build`
- Publish directory: `dist`
- Node: `20`

Trong Netlify → Site configuration → Environment variables, thêm:

```env
API_BASE_URL=https://TEN-BACKEND.onrender.com
```

Trong Render, cập nhật `CORS_ORIGINS` thành URL Netlify thực tế, ví dụ:

```env
CORS_ORIGINS=https://ten-app.netlify.app
```

Deploy lại cả hai dịch vụ sau khi cập nhật biến môi trường tương ứng.

## 5. Kết nối eSMS Live

Hãy chạy Demo và kiểm tra luồng trước. Chỉ chuyển Live sau khi đã đăng ký dịch vụ, được cấp quyền và xác nhận nội dung/template với eSMS.

Biến môi trường Backend cần thiết:

```env
APP_MODE=live
LIVE_SEND_ENABLED=true
ESMS_API_KEY=API_KEY_DO_ESMS_CAP
ESMS_SECRET_KEY=SECRET_KEY_DO_ESMS_CAP

SMS_ENABLED=true
ESMS_BRANDNAME=BRANDNAME_DA_DANG_KY
ESMS_SMS_TYPE=2
ESMS_SANDBOX=1

# Chỉ bật khi tài khoản eSMS được cấp quyền Voice OTP/SmsType 8.
VOICE_ENABLED=false
```

Để nhận trạng thái cuối qua callback, đặt `PUBLIC_BACKEND_URL` và `ESMS_CALLBACK_TOKEN` trên Render. URL callback sẽ được backend tự gắn vào request eSMS; endpoint là `GET /api/webhooks/esms` và kiểm tra token trước khi cập nhật nhật ký. eSMS gửi callback bằng HTTPS GET và có cơ chế retry nếu endpoint timeout.

Khi đã thử nghiệm Sandbox thành công và được eSMS xác nhận có thể gửi thật, đặt `ESMS_SANDBOX=0`. Chỉ bật `VOICE_ENABLED=true` sau khi eSMS xác nhận tài khoản đã được kích hoạt đúng luồng Voice OTP/SmsType 8 và template cần thiết.

**Quan trọng:** `ESMS_API_KEY` và `ESMS_SECRET_KEY` chỉ được đặt trong Environment Variables của Render. Không đưa hai khóa này vào `frontend/config.js`, HTML, JavaScript, Netlify variables hoặc Git.

## 6. Các nguyên tắc an toàn đang áp dụng

1. Backend tự kiểm tra `APP_MODE`; Demo trả kết quả mô phỏng và không thực hiện fetch tới eSMS.
2. Live cần đồng thời `APP_MODE=live`, `LIVE_SEND_ENABLED=true`, API Key và Secret Key.
3. SMS/Voice có công tắc riêng ở Backend; giao diện không thể tự mở quyền gửi.
4. Người thao tác phải xác nhận người nhận đã đồng ý nhận tin/cuộc gọi.
5. Live hiển thị hộp thoại xác nhận trước khi gửi từng tác vụ.
6. Voice chỉ nhận mã OTP số 4–8 chữ số, không phải công cụ gọi thoại tự do.
7. Mỗi tác vụ chỉ có một người nhận; không có gửi hàng loạt trong phiên bản này.
8. Mã Voice OTP được ẩn khỏi nhật ký và được xóa khỏi nội dung tác vụ sau khi xử lý.
9. Không tự động retry request lỗi để tránh gửi trùng hoặc phát sinh phí không chủ ý.

## 7. API Backend chính

| Method | Endpoint | Mục đích |
|---|---|---|
| GET | `/health` | Health check |
| GET | `/api/public-config` | Trạng thái Demo/Live và gợi ý đăng nhập local |
| POST | `/api/auth/login` | Đăng nhập Admin |
| GET | `/api/dashboard` | Số liệu tổng quan |
| POST | `/api/messages/send` | Gửi một SMS/Voice OTP |
| POST | `/api/jobs` | Tạo tác vụ lên lịch |
| GET | `/api/jobs` | Danh sách tác vụ |
| DELETE | `/api/jobs/:id` | Hủy lịch chưa chạy |
| GET | `/api/logs` | Nhật ký hoạt động |
| GET | `/api/settings` | Cấu hình đã che thông tin nhạy cảm |
| GET | `/api/settings/balance` | Truy vấn số dư eSMS (Live) |
| GET | `/api/webhooks/esms` | Callback trạng thái eSMS (token riêng) |

Các endpoint `/api/*` ngoại trừ `/api/public-config` và `/api/auth/login` yêu cầu Bearer JWT.

## 8. Tham khảo eSMS

- [Tài liệu API eSMS](https://developers.esms.vn/)
- [SMS OTP/CSKH — POST JSON](https://developers.esms.vn/esms-api/ham-gui-tin/tin-nhan-sms-otp-cskh)
- [Voice OTP / SmsType 8](https://developers.esms.vn/esms-api/ham-gui-tin/tin-sms-co-dinh-gia-re)
- [Callback trạng thái SMS](https://developers.esms.vn/esms-api/callback-url)
- [API balance / tài liệu tích hợp](https://esms.vn/SMSapi/ApiDetail)

Các quyền Brandname, template, Voice OTP và Sandbox phụ thuộc cấu hình tài khoản eSMS. Vui lòng xác nhận với eSMS trước khi mở gửi thật.
