const crypto = require('node:crypto');
const jwt = require('jsonwebtoken');
const { config } = require('./config');

function constantTimeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  if (left.length !== right.length) {
    const padded = Buffer.alloc(left.length);
    crypto.timingSafeEqual(left, padded);
    return false;
  }
  return crypto.timingSafeEqual(left, right);
}

function login(req, res) {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const valid = constantTimeEqual(email, config.adminEmail.toLowerCase()) && constantTimeEqual(password, config.adminPassword);
  if (!valid) return res.status(401).json({ error: 'Email hoặc mật khẩu không đúng.' });
  const token = jwt.sign({ sub: config.adminEmail, role: 'admin' }, config.jwtSecret, { expiresIn: '8h', issuer: 'esms-management' });
  return res.json({ token, user: { email: config.adminEmail, role: 'admin' }, expiresIn: 28800 });
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Vui lòng đăng nhập.' });
  try {
    req.user = jwt.verify(token, config.jwtSecret, { issuer: 'esms-management' });
    next();
  } catch {
    return res.status(401).json({ error: 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.' });
  }
}

module.exports = { login, requireAuth };
