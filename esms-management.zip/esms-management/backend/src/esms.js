const { config } = require('./config');

const SMS_ENDPOINT = 'https://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_post_json/';
const BALANCE_ENDPOINT = 'https://rest.esms.vn/MainService.svc/json/GetBalance';

function isUnicode(value) {
  return /[^\u0000-\u007f]/.test(value) ? '1' : '0';
}

function safeProviderResult(data) {
  return {
    code: String(data?.CodeResult ?? data?.CodeResponse ?? data?.code ?? ''),
    providerId: String(data?.SMSID ?? data?.SmsId ?? data?.ReferenceId ?? ''),
    errorMessage: String(data?.ErrorMessage ?? data?.error ?? '').slice(0, 400)
  };
}

async function postToEsms(payload) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(SMS_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    const raw = await response.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = { error: raw.slice(0, 300) }; }
    if (!response.ok) throw new Error(`eSMS HTTP ${response.status}: ${safeProviderResult(data).errorMessage || 'Request thất bại'}`);
    return data;
  } finally {
    clearTimeout(timeout);
  }
}

async function send(job) {
  // Chặn tuyệt đối outbound request khi Demo. Không dựa vào giao diện để bảo vệ.
  if (config.mode === 'demo') {
    return {
      status: 'demo', providerId: `DEMO-${job.id.slice(0, 8).toUpperCase()}`,
      providerCode: '100', detail: `Mô phỏng ${job.type === 'voice' ? 'Voice OTP' : 'SMS'} thành công. Không có request nào được gửi đến eSMS.`
    };
  }

  if (!config.liveSendEnabled) throw new Error('Chế độ Live chưa được mở. Kiểm tra LIVE_SEND_ENABLED, API Key và Secret Key.');
  if (job.type === 'sms' && !config.smsEnabled) throw new Error('Tính năng SMS chưa được bật trên backend.');
  if (job.type === 'sms' && !config.esmsBrandname) throw new Error('Thiếu ESMS_BRANDNAME. Brandname phải được đăng ký/kích hoạt với eSMS.');
  if (job.type === 'voice' && !config.voiceEnabled) throw new Error('Tính năng Voice chưa được bật trên backend.');

  const payload = {
    ApiKey: config.esmsApiKey,
    SecretKey: config.esmsSecretKey,
    Content: job.content,
    Phone: job.phone,
    SmsType: job.type === 'voice' ? '8' : config.esmsSmsType,
    RequestId: job.requestId || job.id
  };
  if (config.esmsSandbox) payload.Sandbox = '1';
  if (config.publicBackendUrl && config.esmsCallbackToken) {
    const callback = new URL('/api/webhooks/esms', `${config.publicBackendUrl}/`);
    callback.searchParams.set('token', config.esmsCallbackToken);
    payload.CallbackUrl = callback.toString();
  }
  if (job.type === 'sms') {
    payload.Brandname = config.esmsBrandname;
    payload.IsUnicode = isUnicode(job.content);
    if (job.campaign) payload.campaignid = job.campaign;
  }

  const raw = await postToEsms(payload);
  const result = safeProviderResult(raw);
  if (result.code !== '100') {
    throw new Error(result.errorMessage || `eSMS trả về mã ${result.code || 'không xác định'}.`);
  }
  const sandboxText = config.esmsSandbox ? ' Yêu cầu ở Sandbox; không phải xác nhận phát tin thật.' : '';
  return {
    status: 'accepted', providerId: result.providerId,
    providerCode: result.code,
    detail: `eSMS đã tiếp nhận yêu cầu. Trạng thái 100 không khẳng định tin/cuộc gọi đã đến người nhận.${sandboxText}`
  };
}

async function getBalance() {
  if (config.mode !== 'live' || !config.liveSendEnabled) {
    return { available: false, reason: 'Chỉ truy vấn số dư khi Live đã được bật và thông tin eSMS hợp lệ.' };
  }
  const url = `${BALANCE_ENDPOINT}/${encodeURIComponent(config.esmsApiKey)}/${encodeURIComponent(config.esmsSecretKey)}`;
  const response = await fetch(url, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(12000) });
  const raw = await response.text();
  let data;
  try { data = JSON.parse(raw); } catch { throw new Error('eSMS trả về dữ liệu số dư không hợp lệ.'); }
  if (!response.ok || String(data.CodeResponse ?? data.CodeResult) !== '100') {
    throw new Error(String(data.ErrorMessage || `Không lấy được số dư (mã ${data.CodeResponse ?? data.CodeResult ?? 'không rõ'}).`));
  }
  return { available: true, balance: Number(data.Balance || 0), currency: 'VND', userId: String(data.UserID || '') };
}

module.exports = { send, getBalance };
