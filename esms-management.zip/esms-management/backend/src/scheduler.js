const store = require('./store');
const esms = require('./esms');

let running = false;
let timer = null;

async function tick() {
  if (running) return;
  running = true;
  try {
    const jobs = await store.claimDueJobs(5);
    for (const job of jobs) {
      try {
        const outcome = await esms.send(job);
        await store.finishJob(job, outcome);
      } catch (error) {
        await store.finishJob(job, { status: 'failed', detail: error.message, providerCode: 'LOCAL_ERROR' });
        console.error(`[SCHEDULER] Job ${job.id} thất bại: ${error.message}`);
      }
    }
  } catch (error) {
    console.error(`[SCHEDULER] Không thể xử lý lịch: ${error.message}`);
  } finally {
    running = false;
  }
}

function start() {
  if (timer) return;
  timer = setInterval(tick, 10000);
  timer.unref?.();
  tick();
  console.log('[SCHEDULER] Đã khởi động, kiểm tra lịch mỗi 10 giây.');
}

function stop() {
  if (timer) clearInterval(timer);
  timer = null;
}

module.exports = { start, stop };
