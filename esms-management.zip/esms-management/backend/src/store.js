const fs = require('node:fs/promises');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { Pool } = require('pg');
const { config } = require('./config');

let pool = null;
let fileQueue = Promise.resolve();

function initialState() {
  const now = new Date();
  return {
    jobs: [],
    logs: [
      {
        id: randomUUID(), jobId: null, type: 'sms', phoneMasked: '090***0101',
        messagePreview: 'Đây là nhật ký minh họa trong chế độ Demo.', status: 'demo',
        providerId: 'DEMO-SEED-01', providerCode: '100', detail: 'Bản ghi mô phỏng, không gửi tin thật.',
        createdAt: new Date(now.getTime() - 1000 * 60 * 18).toISOString()
      },
      {
        id: randomUUID(), jobId: null, type: 'voice', phoneMasked: '091***0202',
        messagePreview: 'Mã OTP Demo 246810', status: 'demo',
        providerId: 'DEMO-SEED-02', providerCode: '100', detail: 'Bản ghi mô phỏng, không gọi thật.',
        createdAt: new Date(now.getTime() - 1000 * 60 * 55).toISOString()
      }
    ]
  };
}

async function withFileLock(task) {
  const next = fileQueue.then(task, task);
  fileQueue = next.catch(() => {});
  return next;
}

async function readState() {
  try {
    const raw = await fs.readFile(config.dataFile, 'utf8');
    return JSON.parse(raw);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    const state = initialState();
    await fs.mkdir(path.dirname(config.dataFile), { recursive: true });
    await fs.writeFile(config.dataFile, JSON.stringify(state, null, 2));
    return state;
  }
}

async function writeState(state) {
  await fs.mkdir(path.dirname(config.dataFile), { recursive: true });
  const tempFile = `${config.dataFile}.tmp`;
  await fs.writeFile(tempFile, JSON.stringify(state, null, 2));
  await fs.rename(tempFile, config.dataFile);
}

async function init() {
  if (config.databaseUrl) {
    pool = new Pool({
      connectionString: config.databaseUrl,
      ssl: process.env.PGSSL === 'disable' ? false : { rejectUnauthorized: false },
      max: 5,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000
    });
    await pool.query(`
      CREATE TABLE IF NOT EXISTS message_jobs (
        id UUID PRIMARY KEY,
        type TEXT NOT NULL,
        phone TEXT NOT NULL,
        content TEXT NOT NULL,
        campaign TEXT,
        scheduled_at TIMESTAMPTZ NOT NULL,
        status TEXT NOT NULL DEFAULT 'scheduled',
        consent BOOLEAN NOT NULL DEFAULT FALSE,
        request_id TEXT NOT NULL UNIQUE,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        processing_at TIMESTAMPTZ,
        completed_at TIMESTAMPTZ,
        result JSONB
      );
      CREATE INDEX IF NOT EXISTS idx_message_jobs_due ON message_jobs(status, scheduled_at);
      CREATE TABLE IF NOT EXISTS message_logs (
        id UUID PRIMARY KEY,
        job_id UUID,
        type TEXT NOT NULL,
        phone_masked TEXT NOT NULL,
        message_preview TEXT NOT NULL,
        status TEXT NOT NULL,
        provider_id TEXT,
        provider_code TEXT,
        detail TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_message_logs_created ON message_logs(created_at DESC);
    `);
    console.log('[STORE] PostgreSQL đã sẵn sàng.');
  } else {
    await readState();
    console.log('[STORE] Dùng JSON file local. Trên Render nên cấu hình PostgreSQL để tránh mất dữ liệu khi instance bị thay thế.');
  }
}

function maskPhone(phone) {
  const clean = String(phone || '').replace(/\s/g, '');
  if (clean.length < 7) return '***';
  return `${clean.slice(0, 3)}***${clean.slice(-4)}`;
}

function mapJob(row) {
  return {
    id: row.id,
    type: row.type,
    phone: row.phone,
    content: row.type === 'voice' && ['completed', 'failed'].includes(row.status) ? 'Mã OTP đã được ẩn sau khi xử lý' : row.content,
    campaign: row.campaign || '',
    scheduledAt: new Date(row.scheduled_at || row.scheduledAt).toISOString(),
    status: row.status,
    createdAt: new Date(row.created_at || row.createdAt).toISOString(),
    completedAt: row.completed_at ? new Date(row.completed_at).toISOString() : (row.completedAt || null),
    result: row.result || null
  };
}

async function createJob({ type, phone, content, campaign = '', scheduledAt, consent = true, status = 'scheduled' }) {
  const id = randomUUID();
  const requestId = randomUUID();
  const scheduleDate = new Date(scheduledAt || Date.now());
  if (pool) {
    const { rows } = await pool.query(
      `INSERT INTO message_jobs (id,type,phone,content,campaign,scheduled_at,status,consent,request_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [id, type, phone, content, campaign, scheduleDate, status, consent, requestId]
    );
    return mapJob(rows[0]);
  }
  return withFileLock(async () => {
    const state = await readState();
    const job = { id, type, phone, content, campaign, scheduledAt: scheduleDate.toISOString(), status, consent, requestId, createdAt: new Date().toISOString(), completedAt: null, result: null };
    state.jobs.unshift(job);
    await writeState(state);
    return mapJob(job);
  });
}

async function claimDueJobs(limit = 5) {
  if (pool) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const { rows } = await client.query(
        `SELECT * FROM message_jobs
         WHERE status='scheduled' AND scheduled_at <= NOW()
         ORDER BY scheduled_at ASC
         FOR UPDATE SKIP LOCKED LIMIT $1`, [limit]
      );
      if (rows.length) {
        const ids = rows.map((row) => row.id);
        await client.query(
          `UPDATE message_jobs SET status='processing', processing_at=NOW() WHERE id = ANY($1::uuid[])`, [ids]
        );
      }
      await client.query('COMMIT');
      return rows.map((row) => ({ ...mapJob(row), status: 'processing' }));
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
  return withFileLock(async () => {
    const state = await readState();
    const now = Date.now();
    const due = state.jobs.filter((job) => job.status === 'scheduled' && new Date(job.scheduledAt).getTime() <= now)
      .sort((a, b) => new Date(a.scheduledAt) - new Date(b.scheduledAt)).slice(0, limit);
    for (const job of due) job.status = 'processing';
    if (due.length) await writeState(state);
    return due.map(mapJob);
  });
}

async function finishJob(job, outcome) {
  const log = {
    id: randomUUID(), jobId: job.id, type: job.type, phoneMasked: maskPhone(job.phone),
    messagePreview: job.type === 'voice' ? 'Voice OTP • mã đã được ẩn' : String(job.content).slice(0, 110), status: outcome.status,
    providerId: outcome.providerId || '', providerCode: outcome.providerCode || '',
    detail: String(outcome.detail || '').slice(0, 500), createdAt: new Date().toISOString()
  };
  const jobStatus = outcome.status === 'failed' ? 'failed' : 'completed';
  if (pool) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        `UPDATE message_jobs SET status=$2, completed_at=NOW(), result=$3::jsonb, content=CASE WHEN type='voice' THEN '[REDACTED]' ELSE content END WHERE id=$1`,
        [job.id, jobStatus, JSON.stringify({ status: outcome.status, providerId: log.providerId, providerCode: log.providerCode, detail: log.detail })]
      );
      await client.query(
        `INSERT INTO message_logs (id,job_id,type,phone_masked,message_preview,status,provider_id,provider_code,detail)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [log.id, log.jobId, log.type, log.phoneMasked, log.messagePreview, log.status, log.providerId, log.providerCode, log.detail]
      );
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
    return log;
  }
  return withFileLock(async () => {
    const state = await readState();
    const found = state.jobs.find((item) => item.id === job.id);
    if (found) {
      found.status = jobStatus;
      found.completedAt = log.createdAt;
      found.result = { status: outcome.status, providerId: log.providerId, providerCode: log.providerCode, detail: log.detail };
      if (found.type === 'voice') found.content = '[REDACTED]';
    }
    state.logs.unshift(log);
    state.logs = state.logs.slice(0, 1000);
    await writeState(state);
    return log;
  });
}

async function cancelJob(id) {
  if (pool) {
    const { rowCount } = await pool.query(`UPDATE message_jobs SET status='cancelled' WHERE id=$1 AND status='scheduled'`, [id]);
    return rowCount > 0;
  }
  return withFileLock(async () => {
    const state = await readState();
    const job = state.jobs.find((item) => item.id === id && item.status === 'scheduled');
    if (!job) return false;
    job.status = 'cancelled';
    await writeState(state);
    return true;
  });
}

async function listJobs(limit = 100) {
  if (pool) {
    const { rows } = await pool.query('SELECT * FROM message_jobs ORDER BY created_at DESC LIMIT $1', [limit]);
    return rows.map(mapJob);
  }
  const state = await readState();
  return state.jobs.slice(0, limit).map(mapJob);
}

async function listLogs(limit = 100) {
  if (pool) {
    const { rows } = await pool.query('SELECT * FROM message_logs ORDER BY created_at DESC LIMIT $1', [limit]);
    return rows.map((row) => ({
      id: row.id, jobId: row.job_id, type: row.type, phoneMasked: row.phone_masked,
      messagePreview: row.message_preview, status: row.status, providerId: row.provider_id,
      providerCode: row.provider_code, detail: row.detail, createdAt: new Date(row.created_at).toISOString()
    }));
  }
  const state = await readState();
  return state.logs.slice(0, limit);
}


async function applyCallback({ providerId, sendStatus, sendSuccess, sendFailed, totalPrice }) {
  const statusCode = String(sendStatus || '');
  const successCount = Number(sendSuccess || 0);
  const failedCount = Number(sendFailed || 0);
  let status = 'provider_pending';
  if (statusCode === '4') status = 'provider_rejected';
  else if (statusCode === '5' && failedCount > 0) status = 'delivery_failed';
  else if (statusCode === '5' && successCount > 0) status = 'delivered';
  const detail = `eSMS callback: SendStatus=${statusCode || '—'}, SendSuccess=${successCount}, SendFailed=${failedCount}, TotalPrice=${String(totalPrice || '—')}.`;

  if (pool) {
    const { rows } = await pool.query(
      `UPDATE message_logs SET status=$2, detail=$3 WHERE id = (
         SELECT id FROM message_logs WHERE provider_id=$1 ORDER BY created_at DESC LIMIT 1
       ) RETURNING id`,
      [providerId, status, detail]
    );
    return { matched: rows.length > 0, status };
  }
  return withFileLock(async () => {
    const state = await readState();
    const log = state.logs.find((entry) => String(entry.providerId) === String(providerId));
    if (!log) return { matched: false, status };
    log.status = status;
    log.detail = detail;
    log.callbackAt = new Date().toISOString();
    await writeState(state);
    return { matched: true, status };
  });
}

async function dashboard() {
  const [jobs, logs] = await Promise.all([listJobs(1000), listLogs(1000)]);
  return {
    scheduled: jobs.filter((job) => job.status === 'scheduled').length,
    processing: jobs.filter((job) => job.status === 'processing').length,
    completed: jobs.filter((job) => job.status === 'completed').length,
    failed: jobs.filter((job) => job.status === 'failed').length,
    demo: logs.filter((log) => log.status === 'demo').length,
    accepted: logs.filter((log) => log.status === 'accepted').length,
    recentLogs: logs.slice(0, 6),
    upcomingJobs: jobs.filter((job) => job.status === 'scheduled').slice(0, 5)
  };
}

module.exports = { init, createJob, claimDueJobs, finishJob, cancelJob, listJobs, listLogs, applyCallback, dashboard };
