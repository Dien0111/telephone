const path = require('node:path');

const mode = String(process.env.APP_MODE || 'demo').trim().toLowerCase() === 'live' ? 'live' : 'demo';
const production = process.env.NODE_ENV === 'production';
const apiKey = process.env.ESMS_API_KEY || '';
const secretKey = process.env.ESMS_SECRET_KEY || '';

const config = {
  mode,
  production,
  port: Number(process.env.PORT || 4000),
  corsOrigins: (process.env.CORS_ORIGINS || 'http://localhost:5173,http://localhost:5500,http://127.0.0.1:5500')
    .split(',').map((value) => value.trim()).filter(Boolean),
  adminEmail: process.env.ADMIN_EMAIL || 'admin@demo.local',
  adminPassword: process.env.ADMIN_PASSWORD || (!production && mode === 'demo' ? 'Demo@12345' : ''),
  jwtSecret: process.env.JWT_SECRET || (!production ? 'local-demo-jwt-secret-change-before-deploy-2026' : ''),
  databaseUrl: process.env.DATABASE_URL || '',
  liveSendEnabled: mode === 'live' && process.env.LIVE_SEND_ENABLED === 'true' && Boolean(apiKey && secretKey),
  smsEnabled: process.env.SMS_ENABLED === 'true',
  voiceEnabled: process.env.VOICE_ENABLED === 'true',
  esmsApiKey: apiKey,
  esmsSecretKey: secretKey,
  esmsBrandname: process.env.ESMS_BRANDNAME || '',
  esmsSmsType: process.env.ESMS_SMS_TYPE || '2',
  esmsSandbox: process.env.ESMS_SANDBOX === '1',
  publicBackendUrl: (process.env.PUBLIC_BACKEND_URL || '').replace(/\/$/, ''),
  esmsCallbackToken: process.env.ESMS_CALLBACK_TOKEN || '',
  maxMessageLength: Math.min(2000, Math.max(50, Number(process.env.MAX_MESSAGE_LENGTH || 500))),
  dataFile: path.join(__dirname, '..', 'data', 'store.json')
};

function validateConfig() {
  if (config.production && (!config.jwtSecret || config.jwtSecret.length < 32)) {
    throw new Error('JWT_SECRET phải có ít nhất 32 ký tự khi NODE_ENV=production.');
  }
  if (config.production && !config.adminPassword) {
    throw new Error('Thiếu ADMIN_PASSWORD. Hãy cấu hình mật khẩu quản trị trên Render.');
  }
  if (config.mode === 'live' && config.liveSendEnabled) {
    if (config.smsEnabled && !config.esmsBrandname) {
      console.warn('[CONFIG] SMS_ENABLED=true nhưng thiếu ESMS_BRANDNAME; gửi SMS sẽ bị chặn.');
    }
  }
}

module.exports = { config, validateConfig };
