require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { config, validateConfig } = require('./config');
const auth = require('./auth');
const store = require('./store');
const esms = require('./esms');
const scheduler = require('./scheduler');

validateConfig();
const app = express();
app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({
  origin(origin, callback) {
    if (!origin || (!config.production && origin === 'null') || config.corsOrigins.includes(origin) || config.corsOrigins.includes('*')) return callback(null, true);
    return callback(new Error('Origin không được phép truy cập API.'));
  },
  methods: ['GET', 'POST', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '32kb' }));
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/messages', rateLimit({ windowMs: 60 * 1000, limit: 12, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/jobs', rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'eSMS Management API', mode: config.mode }));
app.get('/api/public-config', (_req, res) => res.json({
  mode: config.mode,
  demoLoginHint: config.mode === 'demo' && !config.production ? { email: config.adminEmail, password: config.adminPassword } : null
}));
app.post('/api/auth/login', auth.login);
app.get('/api/webhooks/esms', async (req, res) => {
  const supplied = String(req.query.token || '');
  const expected = config.esmsCallbackToken;
  const left = Buffer.from(supplied);
  const right = Buffer.from(expected);
  const tokenValid = Boolean(expected && left.length === right.length && require('node:crypto').timingSafeEqual(left, right));
  if (!tokenValid) return res.status(401).send('Unauthorized');
  const providerId = String(req.query.SMSID || '').slice(0, 160);
  if (!providerId) return res.status(400).send('Missing SMSID');
  try {
    const result = await store.applyCallback({
      providerId,
      sendStatus: req.query.SendStatus,
      sendSuccess: req.query.SendSuccess,
      sendFailed: req.query.SendFailed,
      totalPrice: req.query.TotalPrice
    });
    // eSMS chỉ cần xác nhận đã nhận callback; callback không khớp vẫn trả 200 để tránh retry vô hạn.
    return res.status(200).send(result.matched ? 'OK' : 'IGNORED');
  } catch (error) {
    console.error(`[CALLBACK] ${error.message}`);
    return res.status(500).send('Temporary error');
  }
});
app.use('/api', auth.requireAuth);

app.get('/api/me', (req, res) => res.json({ user: { email: req.user.sub, role: req.user.role } }));
app.get('/api/dashboard', async (_req, res, next) => {
  try {
    res.json({ stats: await store.dashboard() });
  } catch (error) { next(error); }
});
app.get('/api/jobs', async (_req, res, next) => {
  try { res.json({ jobs: await store.listJobs(150) }); } catch (error) { next(error); }
});
app.get('/api/logs', async (req, res, next) => {
  try {
    const limit = Math.min(300, Math.max(1, Number(req.query.limit || 100)));
    res.json({ logs: await store.listLogs(limit) });
  } catch (error) { next(error); }
});

function validateRecipient(phone) {
  let value = String(phone || '').replace(/[\s().-]/g, '');
  if (value.startsWith('84')) value = `+${value}`;
  if (value.startsWith('+84')) value = `0${value.slice(3)}`;
  if (!/^0[35789]\d{8}$/.test(value)) throw new Error('Số điện thoại Việt Nam không hợp lệ. Hãy nhập số 10 chữ số bắt đầu bằng 03, 05, 07, 08 hoặc 09.');
  return value;
}

function validateMessage({ type, phone, content, consent }) {
  if (!consent) throw new Error('Bạn cần xác nhận người nhận đã đồng ý nhận SMS/cuộc gọi.');
  if (!['sms', 'voice'].includes(type)) throw new Error('Loại dịch vụ không hợp lệ.');
  const normalizedPhone = validateRecipient(phone);
  const message = String(content || '').trim();
  if (!message) throw new Error('Nội dung không được để trống.');
  if (type === 'sms' && message.length > config.maxMessageLength) throw new Error(`Nội dung SMS vượt quá ${config.maxMessageLength} ký tự.`);
  if (type === 'voice' && !/^\d{4,8}$/.test(message)) throw new Error('Voice OTP chỉ nhận mã số từ 4 đến 8 chữ số theo cấu hình SmsType 8.');
  return { phone: normalizedPhone, content: message };
}

function ensureChannelEnabled(type) {
  if (config.mode === 'demo') return;
  if (!config.liveSendEnabled) throw new Error('Live đang bị khóa. Bật LIVE_SEND_ENABLED=true và cấu hình đủ API Key/Secret Key trên backend trước.');
  if (type === 'sms' && !config.smsEnabled) throw new Error('SMS chưa được bật trong cấu hình backend.');
  if (type === 'voice' && !config.voiceEnabled) throw new Error('Voice chưa được bật trong cấu hình backend.');
}

async function execute(job) {
  try {
    const outcome = await esms.send(job);
    await store.finishJob(job, outcome);
    return outcome;
  } catch (error) {
    const outcome = { status: 'failed', detail: error.message, providerCode: 'LOCAL_ERROR' };
    await store.finishJob(job, outcome);
    error.status = 502;
    throw error;
  }
}

app.post('/api/messages/send', async (req, res, next) => {
  try {
    const clean = validateMessage(req.body || {});
    ensureChannelEnabled(req.body.type);
    const job = await store.createJob({
      type: req.body.type, phone: clean.phone, content: clean.content,
      campaign: String(req.body.campaign || '').trim().slice(0, 100),
      scheduledAt: new Date(), consent: true, status: 'processing'
    });
    const outcome = await execute({ ...job, phone: clean.phone, content: clean.content, requestId: job.id });
    res.status(outcome.status === 'failed' ? 502 : 200).json({ jobId: job.id, outcome });
  } catch (error) { next(error); }
});

app.post('/api/jobs', async (req, res, next) => {
  try {
    const clean = validateMessage(req.body || {});
    ensureChannelEnabled(req.body.type);
    const scheduledAt = new Date(req.body.scheduledAt);
    if (!Number.isFinite(scheduledAt.getTime()) || scheduledAt.getTime() < Date.now() + 15000) {
      throw new Error('Thời gian chạy phải cách hiện tại ít nhất 15 giây.');
    }
    const job = await store.createJob({
      type: req.body.type, phone: clean.phone, content: clean.content,
      campaign: String(req.body.campaign || '').trim().slice(0, 100),
      scheduledAt, consent: true
    });
    res.status(201).json({ job });
  } catch (error) { next(error); }
});

app.delete('/api/jobs/:id', async (req, res, next) => {
  try {
    const cancelled = await store.cancelJob(req.params.id);
    if (!cancelled) return res.status(409).json({ error: 'Không thể hủy lịch này. Lịch có thể đã chạy hoặc không tồn tại.' });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.get('/api/settings', (_req, res) => res.json({
  mode: config.mode,
  liveSendEnabled: config.liveSendEnabled,
  smsEnabled: config.mode === 'demo' || (config.liveSendEnabled && config.smsEnabled),
  voiceEnabled: config.mode === 'demo' || (config.liveSendEnabled && config.voiceEnabled),
  apiConfigured: Boolean(config.esmsApiKey && config.esmsSecretKey),
  brandname: config.esmsBrandname || null,
  sandbox: config.esmsSandbox,
  callbackConfigured: Boolean(config.publicBackendUrl && config.esmsCallbackToken),
  persistence: config.databaseUrl ? 'postgresql' : 'json-local',
  maxMessageLength: config.maxMessageLength
}));

app.get('/api/settings/balance', async (_req, res, next) => {
  try { res.json(await esms.getBalance()); } catch (error) { next(error); }
});

app.use((error, _req, res, _next) => {
  const status = error.status || (error.message?.includes('Origin') ? 403 : 400);
  console.error(`[API] ${error.message}`);
  res.status(status).json({ error: error.message || 'Đã xảy ra lỗi máy chủ.' });
});

async function start() {
  await store.init();
  scheduler.start();
  app.listen(config.port, () => {
    console.log(`eSMS Management API đang chạy tại http://localhost:${config.port}`);
    console.log(`Mode=${config.mode.toUpperCase()} | Live send=${config.liveSendEnabled ? 'ON' : 'OFF'} | Voice=${config.voiceEnabled ? 'ON' : 'OFF'}`);
  });
}

start().catch((error) => {
  console.error(`[STARTUP] ${error.message}`);
  process.exit(1);
});

process.on('SIGTERM', () => { scheduler.stop(); process.exit(0); });
process.on('SIGINT', () => { scheduler.stop(); process.exit(0); });
