@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo [LOI] Chua tim thay Node.js. Hay cai Node.js 20 tro len roi chay lai.
  pause
  exit /b 1
)
cd /d "%~dp0backend"
if not exist ".env" copy ".env.example" ".env" >nul
if not exist "node_modules" (
  echo Dang cai cac goi phu thuoc Backend...
  call npm install
  if errorlevel 1 (
    echo [LOI] npm install that bai. Kiem tra Internet va thu lai.
    pause
    exit /b 1
  )
)
start "eSMS Control Backend - DEMO" cmd /k "cd /d ""%~dp0backend"" && set APP_MODE=demo && set LIVE_SEND_ENABLED=false && set SMS_ENABLED=false && set VOICE_ENABLED=false && npm start"
timeout /t 4 /nobreak >nul
start "" "%~dp0frontend\index.html"
echo.
echo eSMS Control dang mo o che do DEMO.
echo Dang nhap mac dinh: admin@demo.local / Demo@12345
pause
