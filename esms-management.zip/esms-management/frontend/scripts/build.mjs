import { cp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(process.cwd());
const out = resolve(root, 'dist');
await mkdir(out, { recursive: true });
for (const file of ['index.html', 'styles.css', 'app.js']) {
  await cp(resolve(root, file), resolve(out, file));
}
const apiBase = (process.env.API_BASE_URL || 'https://YOUR-RENDER-SERVICE.onrender.com').replace(/\/$/, '');
await writeFile(resolve(out, 'config.js'), `window.APP_CONFIG = { API_BASE_URL: ${JSON.stringify(apiBase)} };\n`);
console.log(`Frontend built. API_BASE_URL=${apiBase}`);
