// Local mặc định. Khi deploy Netlify, scripts/build.mjs sẽ thay bằng biến API_BASE_URL.
window.APP_CONFIG = { API_BASE_URL: 'http://localhost:4000' };
