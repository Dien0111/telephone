(() => {
  const API_BASE = String(window.APP_CONFIG?.API_BASE_URL || 'http://localhost:4000').replace(/\/$/, '');
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const state = {
    token: sessionStorage.getItem('esms_token') || '',
    user: null,
    publicConfig: null,
    settings: null,
    page: 'dashboard',
    dashboard: null,
    jobs: [],
    logs: [],
    balance: null
  };
  const pageMeta = {
    dashboard: ['Tổng quan hoạt động', 'TỔNG QUAN'],
    send: ['Soạn & gửi thông điệp', 'SOẠN & GỬI'],
    jobs: ['Lịch tác vụ', 'LỊCH TÁC VỤ'],
    logs: ['Nhật ký hoạt động', 'NHẬT KÝ'],
    settings: ['Cấu hình hệ thống', 'CẤU HÌNH']
  };

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const formatDate = (value) => value ? new Intl.DateTimeFormat('vi-VN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
  const formatMoney = (value) => new Intl.NumberFormat('vi-VN').format(value) + ' đ';
  const getToken = () => state.token;

  async function api(path, options = {}) {
    const headers = { ...(options.headers || {}) };
    if (options.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
    if (getToken()) headers.Authorization = `Bearer ${getToken()}`;
    let response;
    try {
      response = await fetch(`${API_BASE}${path}`, { ...options, headers });
    } catch {
      throw new Error('Không kết nối được Backend. Kiểm tra Render hoặc API_BASE_URL.');
    }
    const data = await response.json().catch(() => ({}));
    if (response.status === 401 && path !== '/api/auth/login') {
      logout(false);
      throw new Error(data.error || 'Phiên đăng nhập đã hết hạn.');
    }
    if (!response.ok) throw new Error(data.error || `API lỗi ${response.status}`);
    return data;
  }

  function showToast(message, type = 'success') {
    const item = document.createElement('div');
    item.className = `toast ${type}`;
    item.innerHTML = `<span class="toast-mark">${type === 'error' ? '!' : '✓'}</span><span>${esc(message)}</span>`;
    $('#toastRegion').append(item);
    setTimeout(() => item.classList.add('leaving'), 3200);
    setTimeout(() => item.remove(), 3700);
  }

  function showLogin(message = '') {
    $('#appShell').classList.add('hidden');
    $('#loginView').classList.remove('hidden');
    $('#loginError').textContent = message;
  }

  function logout(showMessage = true) {
    state.token = '';
    state.user = null;
    sessionStorage.removeItem('esms_token');
    if (showMessage) $('#loginError').textContent = '';
    showLogin(showMessage ? 'Bạn đã đăng xuất khỏi hệ thống.' : '');
  }

  async function init() {
    $('#todayLabel').textContent = new Intl.DateTimeFormat('vi-VN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }).format(new Date());
    try { state.publicConfig = await api('/api/public-config'); } catch { state.publicConfig = null; }
    if (state.publicConfig?.demoLoginHint) {
      const hint = state.publicConfig.demoLoginHint;
      $('#demoHint').classList.remove('hidden');
      $('#demoHint').innerHTML = `<b>Đăng nhập Demo</b><span>Email: <code>${esc(hint.email)}</code></span><span>Mật khẩu: <code>${esc(hint.password)}</code></span><small>Tài khoản mẫu chỉ dành cho chạy local, hãy thay đổi trước khi triển khai.</small>`;
      $('#loginEmail').value = hint.email;
      $('#loginPassword').value = hint.password;
    }
    if (state.token) {
      try { await enterApp(); } catch { logout(false); }
    } else showLogin();
  }

  async function enterApp() {
    const [me, settings] = await Promise.all([api('/api/me'), api('/api/settings')]);
    state.user = me.user;
    state.settings = settings;
    $('#sidebarEmail').textContent = state.user.email;
    $('#loginView').classList.add('hidden');
    $('#appShell').classList.remove('hidden');
    const mode = settings.mode === 'live' ? 'LIVE MODE' : 'DEMO MODE';
    $('#modeBadge').className = `mode-badge ${settings.mode}`;
    $('#modeBadge span').textContent = mode;
    const notice = $('#modeNotice');
    notice.classList.remove('hidden', 'live-notice');
    if (settings.mode === 'demo') {
      notice.innerHTML = '<span class="notice-symbol">◈</span><div><b>Đang chạy chế độ Demo.</b> Mọi SMS/Voice và lịch chạy chỉ được mô phỏng; backend không gọi eSMS và không phát sinh chi phí.</div><span class="notice-tag">NO REAL SEND</span>';
    } else {
      notice.classList.add('live-notice');
      notice.innerHTML = `<span class="notice-symbol">!</span><div><b>Đang ở chế độ Live.</b> ${settings.liveSendEnabled ? 'Backend đã cho phép gửi. Mỗi thao tác gửi có thể phát sinh chi phí eSMS.' : 'Live hiện đang bị khóa ở backend; cần hoàn tất cấu hình máy chủ trước khi gửi.'}</div><span class="notice-tag">${settings.liveSendEnabled ? 'LIVE' : 'LOCKED'}</span>`;
    }
    await loadAll();
    navigate('dashboard');
  }

  async function loadAll() {
    const [dashboard, jobs, logs, settings] = await Promise.all([
      api('/api/dashboard'), api('/api/jobs'), api('/api/logs?limit=120'), api('/api/settings')
    ]);
    state.dashboard = dashboard.stats;
    state.jobs = jobs.jobs;
    state.logs = logs.logs;
    state.settings = settings;
    renderPage();
  }

  function navigate(page) {
    state.page = pageMeta[page] ? page : 'dashboard';
    $$('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.page === state.page));
    $('#pageTitle').textContent = pageMeta[state.page][0];
    $('#crumbCurrent').textContent = pageMeta[state.page][1];
    $('#sidebar').classList.remove('sidebar-open');
    renderPage();
  }

  function statusPill(status) {
    const map = {
      demo: ['Demo mô phỏng', 'pill-demo'], accepted: ['eSMS tiếp nhận', 'pill-good'],
      failed: ['Thất bại', 'pill-bad'], delivered: ['Đã gửi thành công', 'pill-good'], delivery_failed: ['Gửi thất bại', 'pill-bad'], provider_pending: ['Đang chờ nhà mạng', 'pill-wait'], provider_rejected: ['Bị từ chối', 'pill-bad'], scheduled: ['Đã lên lịch', 'pill-wait'],
      processing: ['Đang xử lý', 'pill-live'], completed: ['Hoàn tất', 'pill-good'],
      cancelled: ['Đã hủy', 'pill-muted']
    };
    const [label, cls] = map[status] || [status || 'Không rõ', 'pill-muted'];
    return `<span class="status-pill ${cls}"><i></i>${label}</span>`;
  }

  function serviceLabel(type) { return type === 'voice' ? 'Voice OTP' : 'SMS'; }
  function logRows(logs) {
    if (!logs.length) return '<tr><td colspan="5"><div class="empty-state"><span>▤</span><b>Chưa có nhật ký</b><small>Hoạt động gửi sẽ xuất hiện tại đây.</small></div></td></tr>';
    return logs.map((log) => `<tr><td><div class="table-main">${esc(serviceLabel(log.type))}</div><small class="table-sub">${esc(log.providerId || '—')}</small></td><td class="mono">${esc(log.phoneMasked)}</td><td class="message-cell">${esc(log.messagePreview)}</td><td>${statusPill(log.status)}</td><td class="date-cell">${formatDate(log.createdAt)}</td></tr>`).join('');
  }
  function jobRows(jobs) {
    if (!jobs.length) return '<tr><td colspan="6"><div class="empty-state"><span>◷</span><b>Chưa có lịch tác vụ</b><small>Tạo lịch mới trong mục Soạn & gửi.</small></div></td></tr>';
    return jobs.map((job) => `<tr><td><div class="table-main">${esc(serviceLabel(job.type))}</div><small class="table-sub">${esc(job.campaign || 'Không có tên chiến dịch')}</small></td><td class="mono">${esc(job.phone)}</td><td class="message-cell">${esc(job.content)}</td><td>${formatDate(job.scheduledAt)}</td><td>${statusPill(job.status)}</td><td>${job.status === 'scheduled' ? `<button class="text-action cancel-job" data-id="${esc(job.id)}">Hủy lịch</button>` : '<span class="muted">—</span>'}</td></tr>`).join('');
  }

  function renderDashboard() {
    const d = state.dashboard || {};
    const sentCount = (d.demo || 0) + (d.accepted || 0);
    const recent = d.recentLogs || [];
    return `
      <div class="page-heading"><div><span class="eyebrow">SYSTEM OVERVIEW</span><h1>Xin chào, <em>Administrator.</em></h1><p>Theo dõi tình trạng gửi tin và các tác vụ đang vận hành.</p></div><button class="btn btn-primary" data-go="send"><span>＋</span> Tạo thông điệp</button></div>
      <div class="stats-grid">
        <article class="stat-card"><div class="stat-top"><span>Tác vụ đã lên lịch</span><span class="stat-icon blue">◷</span></div><strong>${d.scheduled || 0}</strong><small><i class="stat-dot blue-dot"></i> Đang chờ thực thi</small></article>
        <article class="stat-card"><div class="stat-top"><span>Đang xử lý</span><span class="stat-icon amber">⟳</span></div><strong>${d.processing || 0}</strong><small><i class="stat-dot amber-dot"></i> Trong hàng đợi</small></article>
        <article class="stat-card"><div class="stat-top"><span>Đã ghi nhận</span><span class="stat-icon green">✓</span></div><strong>${sentCount}</strong><small><i class="stat-dot green-dot"></i> Bao gồm dữ liệu Demo</small></article>
        <article class="stat-card"><div class="stat-top"><span>Tác vụ lỗi</span><span class="stat-icon red">!</span></div><strong>${d.failed || 0}</strong><small><i class="stat-dot red-dot"></i> Cần kiểm tra</small></article>
      </div>
      <div class="dashboard-grid">
        <section class="panel activity-panel"><div class="panel-heading"><div><span class="eyebrow">RECENT ACTIVITY</span><h2>Hoạt động gần đây</h2></div><button class="text-action" data-go="logs">Xem tất cả ↗</button></div><div class="table-wrap"><table><thead><tr><th>DỊCH VỤ</th><th>NGƯỜI NHẬN</th><th>NỘI DUNG</th><th>TRẠNG THÁI</th><th>THỜI GIAN</th></tr></thead><tbody>${logRows(recent)}</tbody></table></div></section>
        <aside class="right-stack">
          <section class="panel system-panel"><div class="panel-heading"><div><span class="eyebrow">SYSTEM STATUS</span><h2>Trạng thái hệ thống</h2></div><span class="pulse-indicator"></span></div><div class="system-line"><span>Backend API</span><b class="text-green">Đã kết nối</b></div><div class="system-line"><span>Chế độ vận hành</span><b>${state.settings?.mode === 'live' ? 'Live' : 'Demo'}</b></div><div class="system-line"><span>SMS</span><b>${state.settings?.smsEnabled ? 'Sẵn sàng' : 'Đang tắt'}</b></div><div class="system-line"><span>Voice OTP</span><b>${state.settings?.voiceEnabled ? 'Sẵn sàng' : 'Đang tắt'}</b></div><button class="btn btn-quiet btn-wide" data-go="settings">Xem cấu hình <span>↗</span></button></section>
          <section class="quick-card"><div class="quick-orb">✳</div><span class="eyebrow">QUICK ACTION</span><h3>Lên lịch gửi<br />một cách chủ động.</h3><p>Chuẩn bị nội dung và chọn thời điểm thực thi.</p><button class="quick-link" data-go="send">Tạo lịch mới <b>↗</b></button></section>
        </aside>
      </div>
      <div class="footnote"><span>i</span><p><b>Lưu ý về trạng thái:</b> eSMS trả mã 100 nghĩa là hệ thống đã tiếp nhận request, không đồng nghĩa SMS/cuộc gọi đã đến thiết bị người nhận. Trạng thái cuối cần được đối soát qua callback hoặc API trạng thái.</p></div>`;
  }

  function renderSend() {
    const live = state.settings?.mode === 'live';
    const enabled = state.settings?.mode === 'demo' || state.settings?.liveSendEnabled;
    return `<div class="page-heading"><div><span class="eyebrow">MESSAGE COMPOSER</span><h1>Soạn & gửi <em>thông điệp.</em></h1><p>Một người nhận cho mỗi tác vụ để dễ kiểm soát, đối soát và chống gửi nhầm.</p></div><div class="composer-mode">${statusPill(state.settings?.mode === 'demo' ? 'demo' : (enabled ? 'accepted' : 'failed'))}</div></div>
      <div class="composer-layout"><section class="panel composer-panel"><div class="panel-heading"><div><span class="eyebrow">01 / MESSAGE DETAILS</span><h2>Thông tin gửi</h2></div><span class="step-number">01</span></div>
        <form id="sendForm" class="form-grid">
          <div class="field full"><label for="serviceType">Loại dịch vụ</label><div class="service-choice"><label class="service-option"><input type="radio" name="serviceType" value="sms" checked /><span><b class="service-symbol">SMS</b><strong>Tin nhắn SMS</strong><small>OTP / chăm sóc khách hàng</small></span></label><label class="service-option"><input type="radio" name="serviceType" value="voice" /><span><b class="service-symbol voice-symbol">☎</b><strong>Voice OTP</strong><small>Cuộc gọi đọc mã xác thực</small></span></label></div></div>
          <div class="field"><label for="recipientPhone">Số điện thoại người nhận <i>*</i></label><input id="recipientPhone" type="tel" inputmode="tel" placeholder="0912 345 678" autocomplete="off" required /><small>Hỗ trợ số Việt Nam 10 chữ số.</small></div>
          <div class="field"><label for="campaignName">Tên chiến dịch <span>(không bắt buộc)</span></label><input id="campaignName" type="text" maxlength="100" placeholder="Ví dụ: Xác thực tài khoản" /></div>
          <div id="smsContentField" class="field full"><label for="messageContent">Nội dung tin nhắn <i>*</i></label><textarea id="messageContent" rows="5" maxlength="500" placeholder="Nhập nội dung SMS..." required></textarea><div class="field-foot"><small>Không gửi nội dung quảng cáo khi chưa có sự đồng ý.</small><span id="charCount">0 / 500</span></div></div>
          <div id="voiceContentField" class="field full hidden"><label for="voiceCode">Mã Voice OTP <i>*</i></label><input id="voiceCode" type="text" inputmode="numeric" maxlength="8" placeholder="Ví dụ: 246810" /><small>Luồng eSMS SmsType 8 được tài liệu mô tả cho Voice OTP/tin cố định giá rẻ; chỉ bật khi tài khoản được eSMS kích hoạt. Chỉ nhập mã 4–8 chữ số.</small></div>
          <div class="field full schedule-box"><label class="switch-row"><input type="checkbox" id="scheduleToggle" /><span class="switch-ui"></span><span><b>Lên lịch gửi sau</b><small>Đưa tác vụ vào hàng đợi để Backend tự chạy đúng thời điểm.</small></span></label><div id="scheduleFields" class="schedule-fields hidden"><label for="scheduledAt">Thời gian thực hiện</label><input id="scheduledAt" type="datetime-local" /></div></div>
          <label class="consent-check full"><input type="checkbox" id="recipientConsent" /><span>Tôi xác nhận người nhận đã đồng ý nhận SMS/cuộc gọi này và nội dung tuân thủ quy định hiện hành.</span></label>
          <div class="form-actions full"><span class="form-required">* Trường bắt buộc</span><button id="sendSubmit" class="btn btn-primary" type="submit"><span id="sendButtonText">Gửi thử trong Demo</span><b>↗</b></button></div>
        </form>
      </section>
      <aside class="composer-side"><section class="panel preview-panel"><span class="eyebrow">02 / DELIVERY PREVIEW</span><h2>Xem trước tác vụ</h2><div class="preview-device"><div class="device-speaker"></div><div class="preview-screen"><div class="preview-app-icon">${live ? 'e' : 'D'}</div><div class="preview-app-name">${live ? 'eSMS Gateway' : 'Demo Gateway'}</div><div class="preview-time">${new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</div><div id="previewMessage" class="preview-message">Nội dung tin nhắn sẽ hiển thị tại đây.</div><div class="preview-number" id="previewPhone">+84 ••• ••• •••</div></div></div><div class="preview-meta"><div><span>Kênh</span><b id="previewChannel">SMS</b></div><div><span>Lịch chạy</span><b id="previewSchedule">Ngay sau khi xác nhận</b></div><div><span>Chế độ</span><b>${live ? 'Live' : 'Demo'}</b></div></div></section>
        <section class="safety-card"><div class="safety-icon">⌑</div><b>${live ? 'Bạn đang thao tác trên Live' : 'Demo không phát sinh liên lạc thật'}</b><p>${live ? 'Yêu cầu gửi sẽ đi đến eSMS khi backend cho phép. Hãy kiểm tra số điện thoại, nội dung và quyền gửi trước khi xác nhận.' : 'Backend mô phỏng kết quả gửi. Không có API Key, SMS hay cuộc gọi thật được sử dụng.'}</p></section></aside></div>`;
  }

  function renderJobs() {
    return `<div class="page-heading"><div><span class="eyebrow">SCHEDULER QUEUE</span><h1>Lịch <em>tác vụ.</em></h1><p>Backend kiểm tra lịch mỗi 10 giây và tự xử lý các tác vụ đến hạn.</p></div><button class="btn btn-primary" data-go="send">＋ Tạo lịch</button></div><section class="panel"><div class="panel-heading"><div><span class="eyebrow">QUEUE MANAGEMENT</span><h2>Danh sách lịch chạy</h2></div><button class="btn btn-quiet" id="refreshJobs">↻ Làm mới</button></div><div class="table-wrap"><table><thead><tr><th>DỊCH VỤ / CHIẾN DỊCH</th><th>NGƯỜI NHẬN</th><th>NỘI DUNG / MÃ</th><th>THỜI ĐIỂM</th><th>TRẠNG THÁI</th><th>THAO TÁC</th></tr></thead><tbody>${jobRows(state.jobs)}</tbody></table></div></section><div class="footnote"><span>i</span><p>Lịch và nhật ký nên được lưu trên PostgreSQL khi triển khai Render. Không dùng ổ đĩa tạm của instance cho dữ liệu vận hành cần giữ lâu dài.</p></div>`;
  }

  function renderLogs() {
    return `<div class="page-heading"><div><span class="eyebrow">AUDIT TRAIL</span><h1>Nhật ký <em>hoạt động.</em></h1><p>Lưu dấu từng yêu cầu, trạng thái phản hồi và thông tin đối soát.</p></div><button class="btn btn-quiet" id="refreshLogs">↻ Làm mới</button></div><section class="panel"><div class="panel-heading"><div><span class="eyebrow">MESSAGE HISTORY</span><h2>Lịch sử gần đây</h2></div><span class="record-count">${state.logs.length} bản ghi</span></div><div class="table-wrap"><table><thead><tr><th>DỊCH VỤ / ID</th><th>NGƯỜI NHẬN</th><th>NỘI DUNG</th><th>TRẠNG THÁI</th><th>THỜI GIAN</th></tr></thead><tbody>${logRows(state.logs)}</tbody></table></div></section><div class="footnote"><span>i</span><p>Số điện thoại trong nhật ký đã được che một phần. Khi cấu hình CallbackUrl, trạng thái cuối từ eSMS sẽ cập nhật tại đây; mã 100 ban đầu chỉ thể hiện request được tiếp nhận.</p></div>`;
  }

  function renderSettings() {
    const s = state.settings || {};
    return `<div class="page-heading"><div><span class="eyebrow">ENVIRONMENT & SECURITY</span><h1>Cấu hình <em>hệ thống.</em></h1><p>Thông tin cấu hình được đọc từ Backend. Thay đổi biến môi trường trên Render để cập nhật.</p></div></div>
      <div class="settings-grid"><section class="panel settings-panel"><div class="panel-heading"><div><span class="eyebrow">RUNTIME ENVIRONMENT</span><h2>Môi trường vận hành</h2></div>${statusPill(s.mode === 'demo' ? 'demo' : (s.liveSendEnabled ? 'accepted' : 'failed'))}</div><div class="setting-row"><div><b>Chế độ ứng dụng</b><small>APP_MODE</small></div><strong class="setting-value">${s.mode === 'live' ? 'LIVE' : 'DEMO'}</strong></div><div class="setting-row"><div><b>Cho phép gửi thật</b><small>LIVE_SEND_ENABLED</small></div><strong>${s.liveSendEnabled ? '<span class="text-green">Đã bật</span>' : '<span class="text-muted">Đang khóa</span>'}</strong></div><div class="setting-row"><div><b>SMS</b><small>SMS_ENABLED</small></div><strong>${s.smsEnabled ? '<span class="text-green">Đã bật</span>' : '<span class="text-muted">Đang tắt</span>'}</strong></div><div class="setting-row"><div><b>Voice OTP</b><small>VOICE_ENABLED</small></div><strong>${s.voiceEnabled ? '<span class="text-green">Đã bật</span>' : '<span class="text-muted">Đang tắt</span>'}</strong></div><div class="setting-row"><div><b>eSMS API credentials</b><small>ESMS_API_KEY / ESMS_SECRET_KEY</small></div><strong>${s.apiConfigured ? '<span class="text-green">Đã cấu hình · Ẩn giá trị</span>' : '<span class="text-muted">Chưa cấu hình</span>'}</strong></div><div class="setting-row"><div><b>Brandname</b><small>ESMS_BRANDNAME</small></div><strong>${esc(s.brandname || 'Chưa khai báo')}</strong></div><div class="setting-row"><div><b>eSMS Sandbox</b><small>ESMS_SANDBOX</small></div><strong>${s.sandbox ? 'Bật (1)' : 'Tắt (0)'}</strong></div><div class="setting-row"><div><b>Callback trạng thái</b><small>PUBLIC_BACKEND_URL / ESMS_CALLBACK_TOKEN</small></div><strong>${s.callbackConfigured ? '<span class="text-green">Đã cấu hình</span>' : '<span class="text-amber">Chưa cấu hình</span>'}</strong></div><div class="setting-row"><div><b>Lưu trữ dữ liệu</b><small>DATABASE_URL</small></div><strong>${s.persistence === 'postgresql' ? '<span class="text-green">PostgreSQL</span>' : '<span class="text-amber">JSON local</span>'}</strong></div></section>
      <aside class="settings-aside"><section class="panel balance-panel"><span class="eyebrow">ESMS ACCOUNT</span><h2>Số dư tài khoản</h2><div class="balance-value" id="balanceValue">••••••••</div><p id="balanceNote">Số dư chỉ truy vấn trong môi trường Live đã bật.</p><button id="checkBalance" class="btn btn-quiet btn-wide">Kiểm tra số dư <span>↗</span></button></section><section class="security-card"><span class="security-mark">⌑</span><h3>Bảo vệ thông tin xác thực</h3><p>API Key và Secret Key chỉ được lưu trong Environment Variables của Backend Render. Giao diện này không nhận hoặc hiển thị lại các khóa bí mật.</p><a href="https://developers.esms.vn/" target="_blank" rel="noreferrer">Mở tài liệu eSMS ↗</a></section></aside></div>
      <section class="panel deploy-checklist"><div class="panel-heading"><div><span class="eyebrow">DEPLOYMENT CHECKLIST</span><h2>Kiểm tra trước khi mở Live</h2></div></div><div class="check-grid"><div class="check-item"><i>01</i><span><b>Brandname / Template</b><small>Được eSMS đăng ký và kích hoạt.</small></span></div><div class="check-item"><i>02</i><span><b>API Key & Secret Key</b><small>Đặt trong Render Environment, không commit vào Git.</small></span></div><div class="check-item"><i>03</i><span><b>Voice OTP permission</b><small>Xác nhận quyền dịch vụ và mẫu Voice OTP với eSMS.</small></span></div><div class="check-item"><i>04</i><span><b>PostgreSQL</b><small>Dùng cơ sở dữ liệu bền vững cho lịch và nhật ký.</small></span></div></div></section>`;
  }

  function renderPage() {
    const content = $('#pageContent');
    if (!content || $('#appShell').classList.contains('hidden')) return;
    const views = { dashboard: renderDashboard, send: renderSend, jobs: renderJobs, logs: renderLogs, settings: renderSettings };
    content.innerHTML = views[state.page]();
    bindPageEvents();
  }

  function bindPageEvents() {
    $$('[data-go]').forEach((button) => button.addEventListener('click', () => navigate(button.dataset.go)));
    $('#refreshJobs')?.addEventListener('click', refreshJobs);
    $('#refreshLogs')?.addEventListener('click', refreshLogs);
    $$('.cancel-job').forEach((button) => button.addEventListener('click', () => cancelJob(button.dataset.id)));
    bindSendForm();
    $('#checkBalance')?.addEventListener('click', checkBalance);
  }

  function bindSendForm() {
    const form = $('#sendForm');
    if (!form) return;
    const serviceInputs = $$('input[name="serviceType"]', form);
    const message = $('#messageContent');
    const phone = $('#recipientPhone');
    const scheduleToggle = $('#scheduleToggle');
    const scheduleFields = $('#scheduleFields');
    const modeDemo = state.settings?.mode === 'demo';
    const updateType = () => {
      const type = $('input[name="serviceType"]:checked', form).value;
      $('#smsContentField').classList.toggle('hidden', type !== 'sms');
      $('#voiceContentField').classList.toggle('hidden', type !== 'voice');
      $('#previewChannel').textContent = type === 'voice' ? 'Voice OTP' : 'SMS';
      $('#previewMessage').textContent = type === 'voice' ? ($('#voiceCode').value || 'Mã OTP sẽ hiển thị tại đây.') : (message.value || 'Nội dung tin nhắn sẽ hiển thị tại đây.');
    };
    serviceInputs.forEach((input) => input.addEventListener('change', updateType));
    message.addEventListener('input', () => {
      $('#charCount').textContent = `${message.value.length} / ${state.settings?.maxMessageLength || 500}`;
      if ($('input[name="serviceType"]:checked', form).value === 'sms') $('#previewMessage').textContent = message.value || 'Nội dung tin nhắn sẽ hiển thị tại đây.';
    });
    $('#voiceCode').addEventListener('input', (event) => {
      event.target.value = event.target.value.replace(/\D/g, '').slice(0, 8);
      if ($('input[name="serviceType"]:checked', form).value === 'voice') $('#previewMessage').textContent = event.target.value || 'Mã OTP sẽ hiển thị tại đây.';
    });
    phone.addEventListener('input', () => { $('#previewPhone').textContent = phone.value || '+84 ••• ••• •••'; });
    scheduleToggle.addEventListener('change', () => {
      scheduleFields.classList.toggle('hidden', !scheduleToggle.checked);
      $('#previewSchedule').textContent = scheduleToggle.checked ? 'Theo thời gian đã chọn' : 'Ngay sau khi xác nhận';
      if (scheduleToggle.checked) {
        const now = new Date(Date.now() + 30 * 60000);
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        $('#scheduledAt').value = now.toISOString().slice(0, 16);
      }
    });
    form.addEventListener('submit', submitMessage);
    $('#sendButtonText').textContent = modeDemo ? 'Gửi thử trong Demo' : (state.settings?.liveSendEnabled ? 'Xác nhận gửi Live' : 'Live đang bị khóa');
    if (!modeDemo && !state.settings?.liveSendEnabled) $('#sendSubmit').disabled = true;
    updateType();
  }

  async function submitMessage(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const type = $('input[name="serviceType"]:checked', form).value;
    const scheduled = $('#scheduleToggle').checked;
    const payload = {
      type,
      phone: $('#recipientPhone').value.trim(),
      content: type === 'voice' ? $('#voiceCode').value.trim() : $('#messageContent').value.trim(),
      campaign: $('#campaignName').value.trim(),
      consent: $('#recipientConsent').checked
    };
    if (!payload.consent) return showToast('Bạn cần xác nhận sự đồng ý của người nhận.', 'error');
    if (state.settings?.mode === 'live') {
      const warning = type === 'voice' ? 'Thao tác này có thể kích hoạt cuộc gọi Voice OTP thật và phát sinh phí. Tiếp tục?' : 'Thao tác này sẽ gửi SMS thật qua eSMS và có thể phát sinh phí. Bạn đã kiểm tra số điện thoại và nội dung chưa?';
      if (!window.confirm(warning)) return;
    }
    const button = $('#sendSubmit');
    const text = $('#sendButtonText');
    button.disabled = true;
    text.textContent = scheduled ? 'Đang tạo lịch…' : 'Đang xử lý…';
    try {
      if (scheduled) {
        payload.scheduledAt = new Date($('#scheduledAt').value).toISOString();
        await api('/api/jobs', { method: 'POST', body: JSON.stringify(payload) });
        showToast('Đã thêm tác vụ vào lịch chạy.');
        await loadAll();
        navigate('jobs');
      } else {
        const result = await api('/api/messages/send', { method: 'POST', body: JSON.stringify(payload) });
        showToast(result.outcome.status === 'demo' ? 'Demo hoàn tất — không có tin/cuộc gọi thật.' : 'eSMS đã tiếp nhận yêu cầu gửi.');
        await loadAll();
        navigate('logs');
      }
    } catch (error) {
      showToast(error.message, 'error');
      button.disabled = false;
      text.textContent = state.settings?.mode === 'demo' ? 'Gửi thử trong Demo' : 'Xác nhận gửi Live';
    }
  }

  async function refreshJobs() { try { const data = await api('/api/jobs'); state.jobs = data.jobs; renderPage(); showToast('Đã cập nhật danh sách lịch.'); } catch (e) { showToast(e.message, 'error'); } }
  async function refreshLogs() { try { const data = await api('/api/logs?limit=120'); state.logs = data.logs; renderPage(); showToast('Đã cập nhật nhật ký.'); } catch (e) { showToast(e.message, 'error'); } }
  async function cancelJob(id) {
    if (!window.confirm('Bạn chắc chắn muốn hủy lịch tác vụ này?')) return;
    try { await api(`/api/jobs/${encodeURIComponent(id)}`, { method: 'DELETE' }); showToast('Đã hủy lịch tác vụ.'); await loadAll(); }
    catch (error) { showToast(error.message, 'error'); }
  }
  async function checkBalance() {
    const button = $('#checkBalance');
    const note = $('#balanceNote');
    const value = $('#balanceValue');
    button.disabled = true; button.textContent = 'Đang truy vấn…';
    try {
      const data = await api('/api/settings/balance');
      if (data.available) { value.textContent = formatMoney(data.balance); note.textContent = `User ID eSMS: ${data.userId || '—'}. Số dư được truy vấn trực tiếp từ eSMS.`; }
      else { value.textContent = 'Chưa khả dụng'; note.textContent = data.reason; }
    } catch (error) { value.textContent = 'Không truy vấn được'; note.textContent = error.message; }
    finally { button.disabled = false; button.innerHTML = 'Kiểm tra số dư <span>↗</span>'; }
  }

  $('#loginForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = $('button[type="submit"]', event.currentTarget);
    const original = button.innerHTML;
    button.disabled = true; button.textContent = 'Đang xác thực…';
    try {
      const result = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: $('#loginEmail').value, password: $('#loginPassword').value }) });
      state.token = result.token;
      sessionStorage.setItem('esms_token', result.token);
      await enterApp();
    } catch (error) { $('#loginError').textContent = error.message; }
    finally { button.disabled = false; button.innerHTML = original; }
  });
  $('#togglePassword').addEventListener('click', () => {
    const input = $('#loginPassword');
    input.type = input.type === 'password' ? 'text' : 'password';
    $('#togglePassword').textContent = input.type === 'password' ? 'Hiện' : 'Ẩn';
  });
  $('#logoutBtn').addEventListener('click', () => logout(true));
  $$('.nav-item').forEach((item) => item.addEventListener('click', () => navigate(item.dataset.page)));
  $('#mobileMenu').addEventListener('click', () => $('#sidebar').classList.toggle('sidebar-open'));
  init();
})();
